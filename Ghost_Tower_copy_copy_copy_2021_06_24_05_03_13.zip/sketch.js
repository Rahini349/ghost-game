var tower,towerImage
var door,doorImage
var doorsGroup
var climber,climberImage,climbersGroup
var ghost, ghostImage,ghostImage2
var invisibleClimber, invisibleGroup
var gameState = "play"
var ghostSound

function preload(){
  towerImage = loadImage("tower.png");
  doorImage = loadImage("door.png");
  climberImage = loadImage("climber.png");
  ghostImage = loadImage("ghost-jumping.png");
  ghostSound = loadSound("spooky.wav");
  
}
function setup(){
  createCanvas(500,500);
  tower = createSprite(250,250);
  tower.addImage(towerImage);
  tower.velocityY = 1
  
  ghost = createSprite(250,250);
  ghost.addImage(ghostImage);
  ghost.scale = 0.4
  
  doorsGroup = new Group();
  climbersGroup = new Group();
  invisibleGroup = new Group();
  ghostSound.play();
}


function draw(){
  background("black");
  
  if(gameState === "play"){
    
  
  
  if(tower.y > 400){
    tower.y = 300
  }
  spawnDoors()
  
  if(keyDown("right")){
    ghost.x = ghost.x +2
  }
  
   if(keyDown("left")){
    ghost.x = ghost.x -2
  }
  
  
  if(keyDown("space")){
    ghost.velocityY = -10
  }
  
  ghost.velocityY = ghost.velocityY +0.8
  
  if(climbersGroup.isTouching(ghost)){
    ghost.velocityY = 0
  }
  if(invisibleGroup.isTouching(ghost)||ghost.y > 600 ){
    ghost.destroy();
    gameState = "end"
    ghostSound.stop()
  }
  drawSprites();
}
  if(gameState === "end"){
    textSize(50);
    fill("yellow")
    strokeWeight(6)
    stroke("red")
    text("GAMEOVER",100,250);
    
  }
}

function spawnDoors(){
  if(frameCount % 200 === 0){
    door = createSprite(200,-50);
    door.addImage(doorImage);
    
    climber = createSprite(200,10);
    climber.addImage(climberImage);
    invisibleClimber = createSprite(200,15);
    invisibleClimber.width = climber.width
    invisibleClimber.height = 2
    //invisibleClimber.visible = false
    
    door.x = Math.round(random(100,400))
    door.velocityY = 1
    
    climber.x = door.x
    invisibleClimber.x = door.x
    climber.velocityY = 1
    invisibleClimber.velocityY = 1
    
    door.lifetime = 700;
    climber.lifetime = 700
    
    door.depth = ghost.depth
    ghost.depth = ghost.depth+1
    
    doorsGroup.add(door)
    climbersGroup.add(climber)
    invisibleGroup.add(invisibleClimber)
    //invisibleClimber.debug = true
    
    
  }
}






















